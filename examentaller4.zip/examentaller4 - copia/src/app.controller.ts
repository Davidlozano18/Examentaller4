import { Controller, Get, Render } from '@nestjs/common';
import { AppService } from './app.service';

@Controller('/')
export class AppController {
  constructor(private readonly appService: AppService) { }

  @Get('/')
  @Render('index')
  getHello() {
    return { message: 'Hola David Lozano Nestjs' };
  }
  @Get('/ejemplo')
  @Render('ejemplo')
  Hello() {
    return { message: 'Hola profe aca esta mi proyecto en Nestjs' };
  }
}